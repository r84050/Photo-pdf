# PDF Converter — Telegram Mini App

A full-featured PDF Converter Telegram Mini App built with React + Vite + pdf-lib.

## Features
- 📷 **Image → PDF** — Pick photos, reorder, set page size & orientation
- 🔗 **Combine PDFs** — Merge multiple PDFs into one
- 🔒 **Password Protect** — Lock your PDFs
- ✏️ **Rename / Delete** — Manage your PDFs
- ℹ️ **PDF Details** — View file info
- ✈️ **Send to Telegram** — Send generated PDF back to bot
- ⬇️ **Download** — Save to device

## Tech Stack
- React 18 + Vite 5
- pdf-lib (real PDF generation in browser)
- Telegram WebApp SDK

## Setup

```bash
npm install
npm run dev        # local dev
npm run build      # production build → dist/
```

## Deploy to GitHub Pages

1. Push this repo to GitHub
2. Go to **Settings → Pages → Source → GitHub Actions**
3. Push to `main` branch — auto deploys via `.github/workflows/deploy.yml`
4. Your Mini App URL: `https://<username>.github.io/<repo-name>/`

## Bot Integration

In your Aiogram bot, open the Mini App like this:

```python
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, WebAppInfo

kb = InlineKeyboardMarkup(inline_keyboard=[[
    InlineKeyboardButton(
        text="📄 Open PDF Converter",
        web_app=WebAppInfo(url="https://yourusername.github.io/pdf-converter-miniapp/")
    )
]])
await message.answer("Tap below to open PDF Converter:", reply_markup=kb)
```

## Receiving data from Mini App

```python
@dp.message(F.web_app_data)
async def handle_webapp_data(message: Message):
    import json
    data = json.loads(message.web_app_data.data)
    action = data.get("action")

    if action == "pdf_created":
        await message.answer(
            f"✅ PDF created!\n"
            f"📄 {data['name']}\n"
            f"📑 {data['pages']} pages\n"
            f"💾 {data['size']}"
        )
    elif action == "share_pdf":
        await message.answer(f"📤 Sharing: {data['name']}")
```

## Folder Structure

```
src/
├── App.jsx                  # Main app + routing + state
├── App.css                  # All styles (APK-matched theme)
├── main.jsx                 # Entry point
├── hooks/
│   └── useTelegram.js       # Telegram WebApp SDK hook
├── utils/
│   └── pdfUtils.js          # Real PDF generation (pdf-lib)
├── screens/
│   ├── HomeScreen.jsx       # PDF list, search, sort
│   ├── ImageSelectScreen.jsx # Photo picker grid
│   ├── CreatePDFScreen.jsx  # Reorder + page settings
│   ├── GeneratingScreen.jsx # Progress screen
│   ├── SuccessScreen.jsx    # Download / send to Telegram
│   └── CombineScreen.jsx    # Merge PDFs
└── components/
    └── dialogs/
        └── PDFMenuDialog.jsx # Rename, password, detail, delete
```

## Color Theme
- Primary Orange: `#FA6400`
- Background: `#F5F5F5`
- Card: `#FFFFFF`
- Border: `#E8E8E8`
