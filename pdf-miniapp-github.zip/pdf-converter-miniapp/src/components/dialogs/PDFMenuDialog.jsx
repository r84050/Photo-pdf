import React, { useState } from 'react'
import { downloadPDF } from '../../utils/pdfUtils'

export default function PDFMenuDialog({ pdf, onClose, onRename, onDelete, onPasswordSet }) {
  const [showRename, setShowRename] = useState(false)
  const [showPassword, setShowPassword] = useState(false)
  const [showDetail, setShowDetail] = useState(false)
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false)
  const [newName, setNewName] = useState(pdf?.name || '')
  const [pw, setPw] = useState('')
  const [pwConfirm, setPwConfirm] = useState('')

  if (!pdf) return null

  const handleRename = () => {
    if (newName.trim()) {
      onRename(pdf.id, newName.trim())
      setShowRename(false)
      onClose()
    }
  }

  const handlePassword = () => {
    if (pw !== pwConfirm) { alert('Passwords do not match!'); return }
    onPasswordSet(pdf.id, pw)
    setShowPassword(false)
    onClose()
    setPw(''); setPwConfirm('')
  }

  const handleDelete = () => {
    onDelete(pdf.id)
    setShowDeleteConfirm(false)
    onClose()
  }

  if (showDetail) return (
    <div className="overlay center" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="center-dialog">
        <div className="dialog-title">PDF Details</div>
        {[
          ['Name', pdf.name + '.pdf'],
          ['Pages', pdf.pages],
          ['Size', pdf.sizeLabel],
          ['Created', pdf.dateLabel],
          ['Page Size', pdf.pageSize || 'A4'],
          ['Orientation', pdf.orientation || 'Portrait'],
          ['Password', pdf.password ? '🔒 Protected' : 'None'],
        ].map(([label, val]) => (
          <div key={label} className="detail-row">
            <span className="detail-label">{label}</span>
            <span className="detail-val">{val}</span>
          </div>
        ))}
        <div className="dialog-btn-row">
          <button className="dialog-btn primary" onClick={() => { setShowDetail(false); onClose() }}>Close</button>
        </div>
      </div>
    </div>
  )

  if (showDeleteConfirm) return (
    <div className="overlay center" onClick={e => e.target === e.currentTarget && setShowDeleteConfirm(false)}>
      <div className="center-dialog">
        <div className="dialog-title">Delete PDF?</div>
        <p style={{ fontSize: 14, color: 'var(--mid)', marginBottom: 4 }}>
          "{pdf.name}.pdf" will be permanently deleted.
        </p>
        <div className="dialog-btn-row">
          <button className="dialog-btn" onClick={() => setShowDeleteConfirm(false)}>Cancel</button>
          <button className="dialog-btn danger" onClick={handleDelete}>Delete</button>
        </div>
      </div>
    </div>
  )

  if (showRename) return (
    <div className="overlay center" onClick={e => e.target === e.currentTarget && setShowRename(false)}>
      <div className="center-dialog">
        <div className="dialog-title">Rename PDF</div>
        <input
          className="name-input"
          value={newName}
          onChange={e => setNewName(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && handleRename()}
          autoFocus
        />
        <div className="dialog-btn-row">
          <button className="dialog-btn" onClick={() => setShowRename(false)}>Cancel</button>
          <button className="dialog-btn primary" onClick={handleRename}>Rename</button>
        </div>
      </div>
    </div>
  )

  if (showPassword) return (
    <div className="overlay center" onClick={e => e.target === e.currentTarget && setShowPassword(false)}>
      <div className="center-dialog">
        <div className="dialog-title">
          {pdf.password ? 'Change Password' : 'Set Password'}
        </div>
        <input
          className="name-input"
          type="password"
          value={pw}
          onChange={e => setPw(e.target.value)}
          placeholder="Enter password..."
          style={{ marginBottom: 8 }}
          autoFocus
        />
        <input
          className="name-input"
          type="password"
          value={pwConfirm}
          onChange={e => setPwConfirm(e.target.value)}
          placeholder="Confirm password..."
        />
        <div className="dialog-btn-row">
          <button className="dialog-btn" onClick={() => setShowPassword(false)}>Cancel</button>
          <button className="dialog-btn primary" onClick={handlePassword}>Save</button>
        </div>
      </div>
    </div>
  )

  return (
    <div className="overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="bottom-sheet">
        <div className="sheet-handle" />
        <div className="sheet-title">{pdf.name}.pdf</div>
        <div className="sheet-sub">{pdf.pages} pages · {pdf.sizeLabel} · {pdf.dateLabel}</div>

        <div className="sheet-option" onClick={() => setShowRename(true)}>
          <span className="sheet-option-icon">✏️</span>
          Rename
        </div>
        <div className="sheet-option" onClick={() => setShowPassword(true)}>
          <span className="sheet-option-icon">🔒</span>
          {pdf.password ? 'Change Password' : 'Set Password'}
        </div>
        <div className="sheet-option" onClick={() => setShowDetail(true)}>
          <span className="sheet-option-icon">ℹ️</span>
          Details
        </div>
        <div className="sheet-option" onClick={() => { onClose(); if (pdf.bytes) downloadPDF(pdf.bytes, pdf.name) }}>
          <span className="sheet-option-icon">⬇️</span>
          Download
        </div>
        <div className="sheet-option" onClick={() => { onClose(); window.Telegram?.WebApp?.sendData(JSON.stringify({ action: 'share_pdf', name: pdf.name })) }}>
          <span className="sheet-option-icon">✈️</span>
          Send to Telegram
        </div>
        <div className="sheet-option danger" onClick={() => setShowDeleteConfirm(true)}>
          <span className="sheet-option-icon">🗑️</span>
          Delete
        </div>
      </div>
    </div>
  )
}
