import React, { useState, useRef, useCallback, useEffect } from 'react'

export default function ImageSelectScreen({ onBack, onNext }) {
  const [images, setImages] = useState([])
  const [selected, setSelected] = useState([])
  const [previews, setPreviews] = useState({})
  const fileInputRef = useRef()

  useEffect(() => {
    return () => {
      Object.values(previews).forEach(url => URL.revokeObjectURL(url))
    }
  }, [])

  const pickImages = (files) => {
    const arr = Array.from(files)
    const newImgs = arr.map((file, i) => ({
      id: Date.now() + i,
      file,
      name: file.name,
      size: file.size,
    }))
    const newPreviews = {}
    newImgs.forEach(img => {
      newPreviews[img.id] = URL.createObjectURL(img.file)
    })
    setImages(prev => [...prev, ...newImgs])
    setPreviews(prev => ({ ...prev, ...newPreviews }))
  }

  const toggleSelect = useCallback((img) => {
    setSelected(prev => {
      const exists = prev.find(x => x.id === img.id)
      if (exists) {
        return prev.filter(x => x.id !== img.id)
      }
      return [...prev, img]
    })
  }, [])

  const getOrder = (id) => {
    const idx = selected.findIndex(x => x.id === id)
    return idx >= 0 ? idx + 1 : null
  }

  const selectAll = () => {
    if (selected.length === images.length) {
      setSelected([])
    } else {
      setSelected([...images])
    }
  }

  const allSelected = images.length > 0 && selected.length === images.length

  return (
    <>
      <div className="toolbar">
        <button className="tb-btn" onClick={onBack} aria-label="Back">←</button>
        <span className="tb-title">
          {selected.length > 0 ? `${selected.length} Selected` : 'Select Photos'}
        </span>
        {images.length > 0 && (
          <button
            className="tb-btn orange"
            onClick={selectAll}
            style={{ fontSize: 13, fontWeight: 700, width: 'auto', padding: '0 10px' }}
          >
            {allSelected ? 'None' : 'All'}
          </button>
        )}
      </div>

      <div className="content" style={{ padding: 0 }}>
        {images.length === 0 ? (
          <div className="empty-state">
            <div className="empty-icon">🖼️</div>
            <div className="empty-title">Pick photos from gallery</div>
            <div className="empty-sub">Select photos to convert into a PDF</div>
            <button
              className="btn btn-primary"
              style={{ marginTop: 8 }}
              onClick={() => fileInputRef.current?.click()}
            >
              📂 Open Gallery
            </button>
          </div>
        ) : (
          <>
            <div className="img-grid">
              {images.map(img => {
                const order = getOrder(img.id)
                const isSelected = order !== null
                return (
                  <div key={img.id} className="img-cell" onClick={() => toggleSelect(img)}>
                    <img src={previews[img.id]} alt={img.name} loading="lazy" />
                    {isSelected && <div className="sel-overlay" />}
                    {isSelected && <div className="sel-badge">{order}</div>}
                  </div>
                )
              })}
              <div
                className="img-cell"
                style={{ background: '#F0F0F0', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 28, color: '#999', cursor: 'pointer' }}
                onClick={() => fileInputRef.current?.click()}
              >
                +
              </div>
            </div>
          </>
        )}
      </div>

      <div className="sel-bar">
        <span className="sel-count">
          <strong>{selected.length}</strong> {selected.length === 1 ? 'photo' : 'photos'} selected
        </span>
        <button
          className="btn btn-primary"
          disabled={selected.length === 0}
          onClick={() => onNext(selected, previews)}
        >
          Next →
        </button>
      </div>

      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        multiple
        style={{ display: 'none' }}
        onChange={e => e.target.files?.length && pickImages(e.target.files)}
      />
    </>
  )
}
