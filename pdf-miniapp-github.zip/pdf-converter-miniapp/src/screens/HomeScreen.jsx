import React, { useState, useMemo } from 'react'

export default function HomeScreen({ pdfs, onCreatePDF, onCombine, onOpenMenu, navigate }) {
  const [search, setSearch] = useState('')
  const [sortBy, setSortBy] = useState('date')
  const [showSort, setShowSort] = useState(false)

  const filtered = useMemo(() => {
    let list = pdfs.filter(p =>
      p.name.toLowerCase().includes(search.toLowerCase())
    )
    if (sortBy === 'name') list = [...list].sort((a, b) => a.name.localeCompare(b.name))
    else if (sortBy === 'date') list = [...list].sort((a, b) => b.createdAt - a.createdAt)
    else if (sortBy === 'size') list = [...list].sort((a, b) => b.bytes - a.bytes)
    else if (sortBy === 'pages') list = [...list].sort((a, b) => b.pages - a.pages)
    return list
  }, [pdfs, search, sortBy])

  const SORT_LABELS = { name: 'Name', date: 'Date', size: 'Size', pages: 'Pages' }

  return (
    <>
      <div className="toolbar">
        <span className="tb-title">PDF Converter</span>
        <button className="tb-btn orange" onClick={() => setShowSort(true)} aria-label="Sort">
          <span style={{ fontSize: 22 }}>⇅</span>
        </button>
      </div>

      <div className="content">
        <div className="search-bar">
          <span className="search-icon">🔍</span>
          <input
            type="search"
            placeholder="Search PDFs..."
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
        </div>

        <div className="quick-row">
          <div className="quick-card" onClick={onCreatePDF}>
            <div className="quick-card-icon">📷</div>
            <div>
              <div className="quick-card-label">Create PDF</div>
              <div className="quick-card-sub">From photos</div>
            </div>
          </div>
          <div className="quick-card" onClick={onCombine}>
            <div className="quick-card-icon">🔗</div>
            <div>
              <div className="quick-card-label">Combine</div>
              <div className="quick-card-sub">Merge PDFs</div>
            </div>
          </div>
        </div>

        {filtered.length === 0 ? (
          <div className="empty-state">
            <div className="empty-icon">📄</div>
            <div className="empty-title">
              {search ? 'No results found' : 'No PDFs yet'}
            </div>
            <div className="empty-sub">
              {search ? `No PDFs match "${search}"` : 'Tap + to create your first PDF from photos'}
            </div>
          </div>
        ) : (
          <>
            <div className="section-header">
              {filtered.length} PDF{filtered.length !== 1 ? 's' : ''} · Sorted by {SORT_LABELS[sortBy]}
            </div>
            {filtered.map(pdf => (
              <div key={pdf.id} className="pdf-card" onClick={() => onOpenMenu(pdf)}>
                <div className="pdf-thumb">
                  📄
                  <div className="pg-badge">{pdf.pages}</div>
                </div>
                <div className="pdf-info">
                  <div className="pdf-name">{pdf.name}.pdf</div>
                  <div className="pdf-meta">
                    <span>{pdf.sizeLabel}</span>
                    <span>·</span>
                    <span>{pdf.dateLabel}</span>
                    {pdf.password && <span>· 🔒</span>}
                  </div>
                </div>
                <div className="pdf-menu-btn">⋮</div>
              </div>
            ))}
          </>
        )}
        <div style={{ height: 80 }} />
      </div>

      <button className="fab" onClick={onCreatePDF} aria-label="Create PDF">+</button>

      {showSort && (
        <div className="overlay" onClick={e => e.target === e.currentTarget && setShowSort(false)}>
          <div className="bottom-sheet">
            <div className="sheet-handle" />
            <div className="sheet-title">Sort By</div>
            {['name', 'date', 'size', 'pages'].map(opt => (
              <div key={opt} className="sort-row" onClick={() => { setSortBy(opt); setShowSort(false) }}>
                <span style={{ textTransform: 'capitalize' }}>{SORT_LABELS[opt]}</span>
                <div className={`sort-radio ${sortBy === opt ? 'active' : ''}`} />
              </div>
            ))}
          </div>
        </div>
      )}
    </>
  )
}
