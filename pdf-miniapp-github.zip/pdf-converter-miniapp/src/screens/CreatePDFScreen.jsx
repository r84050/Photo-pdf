import React, { useState } from 'react'

const PAGE_SIZES = ['A4', 'Letter', 'A3', 'A5', 'Legal', 'B5']

export default function CreatePDFScreen({ images, previews, onBack, onGenerate }) {
  const [list, setList] = useState(images)
  const [pageSize, setPageSize] = useState('A4')
  const [orientation, setOrientation] = useState('portrait')
  const [pdfName, setPdfName] = useState('Document')

  const moveUp = (idx) => {
    if (idx === 0) return
    const arr = [...list]
    ;[arr[idx - 1], arr[idx]] = [arr[idx], arr[idx - 1]]
    setList(arr)
  }

  const moveDown = (idx) => {
    if (idx === list.length - 1) return
    const arr = [...list]
    ;[arr[idx + 1], arr[idx]] = [arr[idx], arr[idx + 1]]
    setList(arr)
  }

  const remove = (idx) => {
    const arr = list.filter((_, i) => i !== idx)
    if (arr.length === 0) { onBack(); return }
    setList(arr)
  }

  const handleGenerate = () => {
    const name = pdfName.trim() || 'Document'
    onGenerate(list, { pageSize, orientation, name })
  }

  return (
    <>
      <div className="toolbar">
        <button className="tb-btn" onClick={onBack} aria-label="Back">←</button>
        <span className="tb-title">{list.length} Photo{list.length !== 1 ? 's' : ''}</span>
      </div>

      <div className="content">
        <div className="section-header">Photos — Drag to reorder</div>

        <div className="create-list">
          {list.map((img, idx) => (
            <div key={img.id} className="create-row">
              <div className="reorder-btns">
                <button className="reorder-btn" onClick={() => moveUp(idx)} disabled={idx === 0}>▲</button>
                <button className="reorder-btn" onClick={() => moveDown(idx)} disabled={idx === list.length - 1}>▼</button>
              </div>

              {previews[img.id]
                ? <div className="create-thumb"><img src={previews[img.id]} alt={img.name} /></div>
                : <div className="create-thumb-label">🖼️</div>
              }

              <div className="create-info">
                <div className="create-img-name">
                  {img.name || `Photo ${idx + 1}`}
                </div>
                <div className="create-img-sub">
                  Page {idx + 1} of {list.length}
                </div>
              </div>

              <button className="rm-btn" onClick={() => remove(idx)} aria-label="Remove">🗑️</button>
            </div>
          ))}
        </div>

        <div className="settings-section">
          <div className="settings-label">Page Size</div>
          <div className="size-grid">
            {PAGE_SIZES.map(s => (
              <div
                key={s}
                className={`size-opt ${pageSize === s ? 'active' : ''}`}
                onClick={() => setPageSize(s)}
              >{s}</div>
            ))}
          </div>
        </div>

        <div className="settings-section">
          <div className="settings-label">Orientation</div>
          <div className="orient-grid">
            <div
              className={`orient-opt ${orientation === 'portrait' ? 'active' : ''}`}
              onClick={() => setOrientation('portrait')}
            >
              <span style={{ fontSize: 22 }}>📄</span> Portrait
            </div>
            <div
              className={`orient-opt ${orientation === 'landscape' ? 'active' : ''}`}
              onClick={() => setOrientation('landscape')}
            >
              <span style={{ fontSize: 22 }}>🗺️</span> Landscape
            </div>
          </div>
        </div>

        <div style={{ height: 120 }} />
      </div>

      <div className="bottom-bar">
        <input
          className="name-input"
          value={pdfName}
          onChange={e => setPdfName(e.target.value)}
          placeholder="PDF file name..."
        />
        <button className="btn btn-primary btn-full" onClick={handleGenerate}>
          Generate PDF
        </button>
      </div>
    </>
  )
}
