import React from 'react'

export default function GeneratingScreen({ progress, message }) {
  return (
    <>
      <div className="toolbar">
        <span className="tb-title">Creating PDF...</span>
      </div>

      <div className="generating-screen">
        <div
          style={{
            width: 88,
            height: 88,
            background: 'var(--orange-light)',
            borderRadius: 24,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: 44,
            color: 'var(--orange)',
          }}
        >
          <span className="spin" style={{ display: 'inline-block' }}>⚙️</span>
        </div>

        <div style={{ textAlign: 'center' }}>
          <div style={{ fontSize: 17, fontWeight: 600, marginBottom: 6 }}>
            {message || 'Processing...'}
          </div>
          <div style={{ fontSize: 13, color: 'var(--mid)' }}>
            Please don't close the app
          </div>
        </div>

        <div className="progress-wrap" style={{ width: '100%' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
            <span style={{ fontSize: 12, color: 'var(--mid)' }}>Progress</span>
            <span style={{ fontSize: 12, fontWeight: 600, color: 'var(--orange)' }}>
              {Math.round(progress)}%
            </span>
          </div>
          <div className="progress-bar">
            <div className="progress-fill" style={{ width: `${progress}%` }} />
          </div>
        </div>
      </div>
    </>
  )
}
