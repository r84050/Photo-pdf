import React, { useState, useRef } from 'react'
import { formatBytes } from '../utils/pdfUtils'

export default function CombineScreen({ onBack, onCombined }) {
  const [tab, setTab] = useState(0)
  const [available, setAvailable] = useState([])
  const [selected, setSelected] = useState([])
  const [name, setName] = useState('Combined')
  const fileInputRef = useRef()

  const pickPDFs = (files) => {
    const arr = Array.from(files).map((f, i) => ({
      id: Date.now() + i,
      file: f,
      name: f.name.replace('.pdf', ''),
      pages: Math.floor(Math.random() * 20) + 1,
      sizeLabel: formatBytes(f.size),
    }))
    setAvailable(prev => [...prev, ...arr])
  }

  const addToSelected = (item) => {
    setAvailable(prev => prev.filter(x => x.id !== item.id))
    setSelected(prev => [...prev, item])
  }

  const removeFromSelected = (item) => {
    setSelected(prev => prev.filter(x => x.id !== item.id))
    setAvailable(prev => [...prev, item])
  }

  const handleCombine = () => {
    if (selected.length < 2) {
      alert('Select at least 2 PDFs to combine!')
      return
    }
    onCombined(selected.map(s => s.file), name.trim() || 'Combined')
  }

  return (
    <>
      <div className="toolbar">
        <button className="tb-btn" onClick={onBack} aria-label="Back">←</button>
        <span className="tb-title">Combine PDFs</span>
        <button
          className="tb-btn orange"
          onClick={() => fileInputRef.current?.click()}
          aria-label="Add PDF"
        >+</button>
      </div>

      <div className="tab-bar">
        <div className={`tab-item ${tab === 0 ? 'active' : ''}`} onClick={() => setTab(0)}>
          Available ({available.length})
        </div>
        <div className={`tab-item ${tab === 1 ? 'active' : ''}`} onClick={() => setTab(1)}>
          Selected ({selected.length})
        </div>
      </div>

      <div className="content">
        {tab === 0 && (
          <>
            {available.length === 0 ? (
              <div className="empty-state">
                <div className="empty-icon">📂</div>
                <div className="empty-title">No PDFs added</div>
                <div className="empty-sub">Tap + to pick PDFs from your device</div>
                <button
                  className="btn btn-primary"
                  style={{ marginTop: 8 }}
                  onClick={() => fileInputRef.current?.click()}
                >
                  Add PDFs
                </button>
              </div>
            ) : (
              available.map(item => (
                <div key={item.id} className="combine-card">
                  <div className="combine-thumb">📄</div>
                  <div className="combine-info">
                    <div className="combine-name">{item.name}.pdf</div>
                    <div className="combine-sub">{item.sizeLabel}</div>
                  </div>
                  <button className="combine-add-btn add" onClick={() => addToSelected(item)}>+</button>
                </div>
              ))
            )}
          </>
        )}

        {tab === 1 && (
          <>
            {selected.length === 0 ? (
              <div className="empty-state">
                <div className="empty-icon">📋</div>
                <div className="empty-title">Nothing selected</div>
                <div className="empty-sub">Go to Available tab and add PDFs</div>
              </div>
            ) : (
              selected.map((item, idx) => (
                <div key={item.id} className="combine-card">
                  <div
                    className="combine-thumb"
                    style={{ fontSize: 15, fontWeight: 700, color: 'var(--orange)' }}
                  >
                    {idx + 1}
                  </div>
                  <div className="combine-info">
                    <div className="combine-name">{item.name}.pdf</div>
                    <div className="combine-sub">{item.sizeLabel}</div>
                  </div>
                  <button className="combine-add-btn remove" onClick={() => removeFromSelected(item)}>✕</button>
                </div>
              ))
            )}
          </>
        )}

        <div style={{ height: 120 }} />
      </div>

      <div className="bottom-bar">
        <input
          className="name-input"
          value={name}
          onChange={e => setName(e.target.value)}
          placeholder="Combined PDF name..."
        />
        <button
          className="btn btn-primary btn-full"
          disabled={selected.length < 2}
          onClick={handleCombine}
        >
          Combine {selected.length > 0 ? `${selected.length} PDFs` : 'PDFs'}
        </button>
      </div>

      <input
        ref={fileInputRef}
        type="file"
        accept="application/pdf"
        multiple
        style={{ display: 'none' }}
        onChange={e => e.target.files?.length && pickPDFs(e.target.files)}
      />
    </>
  )
}
