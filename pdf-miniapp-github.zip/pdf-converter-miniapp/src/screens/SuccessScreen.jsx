import React from 'react'
import { downloadPDF } from '../utils/pdfUtils'

export default function SuccessScreen({ pdf, pdfBytes, onHome, onViewPDF }) {
  const handleDownload = () => {
    if (pdfBytes) downloadPDF(pdfBytes, pdf.name)
  }

  const handleTelegram = () => {
    const tg = window.Telegram?.WebApp
    if (tg) {
      tg.sendData(JSON.stringify({
        action: 'pdf_created',
        name: pdf.name + '.pdf',
        pages: pdf.pages,
        size: pdf.sizeLabel,
      }))
    } else {
      handleDownload()
    }
  }

  return (
    <>
      <div className="toolbar">
        <button className="tb-btn" onClick={onHome} aria-label="Home">←</button>
        <span className="tb-title">Success!</span>
      </div>

      <div className="success-screen">
        <div className="success-icon">📄</div>

        <div className="success-title">{pdf.name}.pdf</div>
        <div className="success-sub">
          {pdf.pages} page{pdf.pages !== 1 ? 's' : ''} · {pdf.sizeLabel} · {pdf.pageSize} {pdf.orientation}
          {pdf.password && '\n🔒 Password protected'}
        </div>

        <div className="success-actions">
          <button className="btn btn-primary btn-full" onClick={handleTelegram}>
            ✈️ Send to Telegram
          </button>
          <button className="btn btn-outline btn-full" onClick={handleDownload}>
            ⬇️ Download PDF
          </button>
          {onViewPDF && (
            <button className="btn btn-outline btn-full" onClick={onViewPDF}>
              👁️ View PDF
            </button>
          )}
          <button
            style={{ border: 'none', background: 'transparent', color: 'var(--mid)', fontSize: 14, cursor: 'pointer', padding: 10 }}
            onClick={onHome}
          >
            Back to Home
          </button>
        </div>
      </div>
    </>
  )
}
