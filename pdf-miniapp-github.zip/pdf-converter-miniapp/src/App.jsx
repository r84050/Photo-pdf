import React, { useState, useEffect, useCallback, useRef } from 'react'
import { useTelegram } from './hooks/useTelegram'
import { generatePDFFromImages, combinePDFs, formatBytes, formatDate } from './utils/pdfUtils'
import HomeScreen from './screens/HomeScreen'
import ImageSelectScreen from './screens/ImageSelectScreen'
import CreatePDFScreen from './screens/CreatePDFScreen'
import GeneratingScreen from './screens/GeneratingScreen'
import SuccessScreen from './screens/SuccessScreen'
import CombineScreen from './screens/CombineScreen'
import PDFMenuDialog from './components/dialogs/PDFMenuDialog'

const SCREENS = ['home', 'image-select', 'create', 'generating', 'success', 'combine']

const STORAGE_KEY = 'pdf_converter_list'

function loadPDFs() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    return raw ? JSON.parse(raw) : []
  } catch { return [] }
}

function savePDFs(list) {
  try {
    const toSave = list.map(p => ({ ...p, bytes: undefined }))
    localStorage.setItem(STORAGE_KEY, JSON.stringify(toSave))
  } catch {}
}

export default function App() {
  const { onReady, expand } = useTelegram()
  const [screen, setScreen] = useState('home')
  const [history, setHistory] = useState([])
  const [pdfs, setPdfs] = useState(loadPDFs)
  const [selectedImages, setSelectedImages] = useState([])
  const [imagePreviews, setImagePreviews] = useState({})
  const [progress, setProgress] = useState(0)
  const [progressMsg, setProgressMsg] = useState('')
  const [currentPDF, setCurrentPDF] = useState(null)
  const [currentPDFBytes, setCurrentPDFBytes] = useState(null)
  const [menuPDF, setMenuPDF] = useState(null)

  useEffect(() => {
    onReady()
    expand()
  }, [])

  useEffect(() => { savePDFs(pdfs) }, [pdfs])

  const navigate = useCallback((to) => {
    setHistory(prev => [...prev, screen])
    setScreen(to)
  }, [screen])

  const goBack = useCallback(() => {
    setHistory(prev => {
      const newHist = [...prev]
      const last = newHist.pop()
      setScreen(last || 'home')
      return newHist
    })
  }, [])

  const goHome = useCallback(() => {
    setHistory([])
    setScreen('home')
  }, [])

  const handleCreatePDF = useCallback(() => {
    navigate('image-select')
  }, [navigate])

  const handleImageSelectNext = useCallback((images, previews) => {
    setSelectedImages(images)
    setImagePreviews(previews)
    navigate('create')
  }, [navigate])

  const handleGenerate = useCallback(async (images, { pageSize, orientation, name, password }) => {
    navigate('generating')
    setProgress(0)
    setProgressMsg('Processing images...')

    try {
      const msgs = [
        'Processing images...',
        'Creating pages...',
        'Applying settings...',
        'Finalizing PDF...',
      ]
      let msgIdx = 0
      const msgTimer = setInterval(() => {
        msgIdx = Math.min(msgIdx + 1, msgs.length - 1)
        setProgressMsg(msgs[msgIdx])
      }, 800)

      const pdfBytes = await generatePDFFromImages(
        images,
        { pageSize, orientation, password },
        (p) => setProgress(p)
      )

      clearInterval(msgTimer)
      setProgress(100)

      await new Promise(r => setTimeout(r, 300))

      const newPDF = {
        id: Date.now(),
        name,
        pages: images.length,
        bytes: Array.from(pdfBytes),
        sizeLabel: formatBytes(pdfBytes.length),
        dateLabel: formatDate(),
        pageSize,
        orientation: orientation.charAt(0).toUpperCase() + orientation.slice(1),
        password: !!password,
        createdAt: Date.now(),
        bytesLen: pdfBytes.length,
      }

      setPdfs(prev => [newPDF, ...prev])
      setCurrentPDF(newPDF)
      setCurrentPDFBytes(pdfBytes)
      navigate('success')
    } catch (err) {
      console.error(err)
      alert('Error generating PDF: ' + err.message)
      goHome()
    }
  }, [navigate, goHome])

  const handleCombine = useCallback(async (files, name) => {
    navigate('generating')
    setProgress(0)
    setProgressMsg('Merging PDFs...')

    try {
      const pdfBytes = await combinePDFs(files, p => setProgress(p))
      setProgress(100)
      await new Promise(r => setTimeout(r, 300))

      const newPDF = {
        id: Date.now(),
        name,
        pages: files.length * 5,
        bytes: Array.from(pdfBytes),
        sizeLabel: formatBytes(pdfBytes.length),
        dateLabel: formatDate(),
        pageSize: 'Mixed',
        orientation: 'Mixed',
        password: false,
        createdAt: Date.now(),
      }

      setPdfs(prev => [newPDF, ...prev])
      setCurrentPDF(newPDF)
      setCurrentPDFBytes(pdfBytes)
      navigate('success')
    } catch (err) {
      console.error(err)
      alert('Error combining PDFs: ' + err.message)
      goHome()
    }
  }, [navigate, goHome])

  const handleRename = useCallback((id, newName) => {
    setPdfs(prev => prev.map(p => p.id === id ? { ...p, name: newName } : p))
  }, [])

  const handleDelete = useCallback((id) => {
    setPdfs(prev => prev.filter(p => p.id !== id))
  }, [])

  const handlePasswordSet = useCallback((id, password) => {
    setPdfs(prev => prev.map(p => p.id === id ? { ...p, password: !!password } : p))
  }, [])

  const renderScreen = () => {
    switch (screen) {
      case 'home':
        return (
          <HomeScreen
            pdfs={pdfs}
            onCreatePDF={handleCreatePDF}
            onCombine={() => navigate('combine')}
            onOpenMenu={setMenuPDF}
            navigate={navigate}
          />
        )
      case 'image-select':
        return (
          <ImageSelectScreen
            onBack={goBack}
            onNext={handleImageSelectNext}
          />
        )
      case 'create':
        return (
          <CreatePDFScreen
            images={selectedImages}
            previews={imagePreviews}
            onBack={goBack}
            onGenerate={handleGenerate}
          />
        )
      case 'generating':
        return (
          <GeneratingScreen
            progress={progress}
            message={progressMsg}
          />
        )
      case 'success':
        return (
          <SuccessScreen
            pdf={currentPDF}
            pdfBytes={currentPDFBytes}
            onHome={goHome}
          />
        )
      case 'combine':
        return (
          <CombineScreen
            onBack={goBack}
            onCombined={handleCombine}
          />
        )
      default:
        return null
    }
  }

  return (
    <div className="app">
      <div className="screen">
        {renderScreen()}
      </div>

      {menuPDF && (
        <PDFMenuDialog
          pdf={menuPDF}
          onClose={() => setMenuPDF(null)}
          onRename={handleRename}
          onDelete={handleDelete}
          onPasswordSet={handlePasswordSet}
        />
      )}
    </div>
  )
}
