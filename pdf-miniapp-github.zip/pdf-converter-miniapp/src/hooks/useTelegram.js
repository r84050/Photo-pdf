const tg = window.Telegram?.WebApp

export function useTelegram() {
  const onClose = () => tg?.close()
  const onReady = () => tg?.ready()
  const expand = () => tg?.expand()
  const sendData = (data) => tg?.sendData(JSON.stringify(data))
  const haptic = (type = 'light') => tg?.HapticFeedback?.impactOccurred(type)
  const showAlert = (msg, cb) => tg?.showAlert(msg, cb)
  const showConfirm = (msg, cb) => tg?.showConfirm(msg, cb)

  return {
    tg,
    user: tg?.initDataUnsafe?.user,
    colorScheme: tg?.colorScheme || 'light',
    onClose,
    onReady,
    expand,
    sendData,
    haptic,
    showAlert,
    showConfirm,
  }
}
