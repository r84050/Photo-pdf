import { PDFDocument, degrees } from 'pdf-lib'

export const PAGE_SIZES = {
  A4:     [595.28, 841.89],
  A3:     [841.89, 1190.55],
  A5:     [419.53, 595.28],
  Letter: [612, 792],
  Legal:  [612, 1008],
  B5:     [498.90, 708.66],
}

function readFileAsArrayBuffer(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = (e) => resolve(e.target.result)
    reader.onerror = reject
    reader.readAsArrayBuffer(file)
  })
}

function imageToJpegBytes(file) {
  return new Promise((resolve, reject) => {
    const img = new Image()
    const url = URL.createObjectURL(file)
    img.onload = () => {
      const canvas = document.createElement('canvas')
      canvas.width = img.naturalWidth
      canvas.height = img.naturalHeight
      const ctx = canvas.getContext('2d')
      ctx.drawImage(img, 0, 0)
      canvas.toBlob((blob) => {
        URL.revokeObjectURL(url)
        blob.arrayBuffer().then(resolve).catch(reject)
      }, 'image/jpeg', 0.92)
    }
    img.onerror = reject
    img.src = url
  })
}

export async function generatePDFFromImages(images, { pageSize = 'A4', orientation = 'portrait', password = null }, onProgress) {
  const pdfDoc = await PDFDocument.create()
  let [w, h] = PAGE_SIZES[pageSize] || PAGE_SIZES.A4
  if (orientation === 'landscape') [w, h] = [h, w]

  for (let i = 0; i < images.length; i++) {
    onProgress && onProgress(Math.round((i / images.length) * 80))
    const file = images[i].file
    let imageBytes
    try {
      if (file.type === 'image/jpeg' || file.type === 'image/jpg') {
        imageBytes = await readFileAsArrayBuffer(file)
      } else {
        imageBytes = await imageToJpegBytes(file)
      }
      const embeddedImg = await pdfDoc.embedJpg(imageBytes)
      const page = pdfDoc.addPage([w, h])
      const { width: iw, height: ih } = embeddedImg.size()
      const margin = 20
      const maxW = w - margin * 2
      const maxH = h - margin * 2
      const scale = Math.min(maxW / iw, maxH / ih)
      const sw = iw * scale
      const sh = ih * scale
      page.drawImage(embeddedImg, {
        x: (w - sw) / 2,
        y: (h - sh) / 2,
        width: sw,
        height: sh,
      })
    } catch (err) {
      console.error('Image embed error:', err)
    }
  }

  onProgress && onProgress(90)

  let pdfBytes
  if (password) {
    pdfBytes = await pdfDoc.save({
      userPassword: password,
      ownerPassword: password + '_owner',
      permissions: { modifying: false, copying: false },
    })
  } else {
    pdfBytes = await pdfDoc.save()
  }

  onProgress && onProgress(100)
  return pdfBytes
}

export async function combinePDFs(pdfFiles, onProgress) {
  const merged = await PDFDocument.create()
  for (let i = 0; i < pdfFiles.length; i++) {
    onProgress && onProgress(Math.round((i / pdfFiles.length) * 90))
    const bytes = await readFileAsArrayBuffer(pdfFiles[i])
    const doc = await PDFDocument.load(bytes)
    const pages = await merged.copyPages(doc, doc.getPageIndices())
    pages.forEach(p => merged.addPage(p))
  }
  onProgress && onProgress(100)
  return await merged.save()
}

export function downloadPDF(bytes, name) {
  const blob = new Blob([bytes], { type: 'application/pdf' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = name.endsWith('.pdf') ? name : name + '.pdf'
  a.click()
  URL.revokeObjectURL(url)
}

export function formatBytes(bytes) {
  if (bytes < 1024) return bytes + ' B'
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB'
  return (bytes / (1024 * 1024)).toFixed(2) + ' MB'
}

export function formatDate(d = new Date()) {
  return d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })
}
